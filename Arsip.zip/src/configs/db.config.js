module.exports = {
    HOST: "localhost",
    USER: "stackind_mekarsari",
    PASSWORD: "stackind_mekarsari",
    DB: "stackind_mekarsari",
    dialect: "mysql",
    pool: {
      max: 5,
      min: 0,
      acquire: 30000,
      idle: 10000
    }
  };