module.exports = {
    secret: "galon-secret-key"
  };